<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<script src="assets/bootstrap/js/jquery-3.1.0.js"></script>
		<script src="assets/bootstrap/js/bootstrap.js"></script>
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
		<title>Poliklinik</title>
	</head>
	<body>
		<script>
			window.location.href="admin/?page=pasien";
		</script>
	</body>
</html>