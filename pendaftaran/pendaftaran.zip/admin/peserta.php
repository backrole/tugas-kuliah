<div class="col-md-12">
				<div style="border-left:3px solid blue;" class="well well-sm"><a href=".?page=peserta">Peserta</a></div>
		</div>
		<!-- panel -->
		<div class="col-md-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<span class="panel-title">Peserta</span>
				</div>
				<div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
								<th>No Identitas</th>
								<th>Nama</th>
								<th>Audisi</th>
								<th>Jenis Kelamin</th>
								<th>Status</th>
								<th>TTL</th>
								<th>Alamat</th>
								<th>Kode Pos</th>
								<th>Provinsi</th>
								<th>Telepon</th>
								<th>Opsi</th>
							</tr>
						</thead>
						<tbody>
						<?php 
						$tampil = $db->prepare("SELECT * FROM daftar");
						$tampil->execute();
						while ($data = $tampil->fetch(PDO::FETCH_LAZY)) {
							?>
							<tr>
								<td><?php echo $data->no_identitas; ?></td>
								<td><?php echo $data->nama; ?></td>
								<td><?php echo $data->audisi; ?></td>
								<td><?php echo $data->jk; ?></td>
								<td><?php echo $data->status; ?></td>
								<td><?php echo $data->tempat_lahir; ?>,<?php echo $data->tgl_lahir; ?></td>
								<td><?php echo $data->alamat; ?></td>
								<td><?php echo $data->kode_pos; ?></td>
								<td><?php echo $data->provinsi; ?></td>
								<td><?php echo $data->telepon; ?></td>
								<td>
									<a href=".?page=peserta&action=edit&kd=<?php echo $data->no_pendaftaran; ?>" class="btn btn-primary">Edit</a>
									<a href=".?page=peserta&action=delete&kd=<?php echo $data->no_pendaftaran; ?>" class="btn btn-danger">Delete</a>
								</td>
							</tr>
							<?php
						}
						?>
						</tbody>
					</table>
				</div>
			</div>
		</div>