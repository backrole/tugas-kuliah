<div class="col-md-12">
				<div style="border-left:3px solid blue;" class="well well-sm"><a href=".?page=peserta">Peserta</a></div>
		</div>
		<!-- panel -->
		<div class="col-md-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<span class="panel-title">Peserta</span>
				</div>
				<div class="panel-body">
					<form method="post" role="form">
				<legend>Edit Peserta</legend>

				<div class="form-group">
					<label for="">No Identitas</label>
					<input type="text" class="form-control" id="" required name="no_indentitas">
				</div>
	
				<div class="form-group">
					<label for="">Audisi</label>
					<select name="audisi" id="" required class="form-control">
						<option value="" selected="selected" disabled="disabled">Pilih Lokasi</option>
						<?php  
				          $tampil = $db->query("SELECT * FROM audisi");
				          $tampil->execute();
				          while ($data = $tampil->fetch(PDO::FETCH_LAZY)) {
				           ?>
				           <option value="<?php echo $data->lokasi; ?>"><?php echo $data->lokasi; ?></option>
				           <?php  
				           }
				           ?>
					</select>
				</div>

				<div class="form-group">
					<label for="">Nama</label>
					<input type="text" class="form-control" id="" required name="nama">
				</div>
				<div class="form-group">
					<label for="">Jenis Kelamin</label>
					<select name="jk" id="" required class="form-control">
						<option value="" selected="selected" disabled="disabled">Pilih Jenis Kelamin</option>
						<option value="laki-laki" >Laki-Laki</option>
						<option value="perempuan" >Perempuan</option>
					</select>
				</div>
				<div class="form-group">
					<label for="">Status</label>
					<select name="status" id="" required class="form-control">
						<option value="" selected="selected" disabled="disabled">Pilih Status</option>
						<option value="belum menikah" >Belum Menikah</option>
						<option value="menikah" >Menikah</option>
						<option value="pernah menikah" >Pernah Menikah</option>
					</select>
				</div>
				<div class="form-group">
					<label for="">Tempat Lahir</label>
					<input type="text" class="form-control" id="" name="tempat_lahir" required>
				</div>
				<div class="form-group">
					<label for="">Tanggal Lahir</label>
					<input type="date" class="form-control" id="" name="tgl_lahir" required>
				</div>
				<div class="form-group">
					<label for="">Alamat</label>
					<input type="text" class="form-control" id="" name="alamat" required>
				</div>
				<div class="form-group">
					<label for="">Kota</label>
					<input type="text" class="form-control" id="" name="kota" required>
				</div>
				<div class="form-group">
					<label for="">Provinsi</label>
					<select name="provinsi" id="" required class="form-control">
						<option value="" selected="selected" disabled="disabled">Pilih Provinsi</option>
						<?php
						$tampil = $db->query("SELECT * FROM t_provinsi");
						$tampil->execute();
						while ($data = $tampil->fetch(PDO::FETCH_LAZY)) {
							?>
							<option value="<?php echo $data->nama; ?>"><?php echo $data->nama; ?></option>
							<?php  
						}
						?>
					</select>
				</div>
				<div class="form-group">
					<label for="">Kode Pos</label>
					<input type="text" class="form-control" id="" name="kode_pos" required>
				</div>
				<div class="form-group">
					<label for="">Pekerjaan</label>
					<input type="text" class="form-control" id="" name="pekerjaan" required>
				</div>
				<div class="form-group">
					<label for="">Telepon</label>
					<input type="text" class="form-control" id="" name="telepon" required>
				</div>

				<button type="submit" name="kirim" value="kirim" class="btn btn-primary">Send</button>
				<input type="reset" value="Reset" class="btn btn-danger">
			</form>
				</div>
			</div>
		</div>